﻿using finalProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace finalProject.Controllers
{
    public class CharactersController : Controller
    {
        private readonly AppDbContext _context;

        public CharactersController(AppDbContext context)
        {
            _context = context;
        }

        // Displays the Add Character page for a specific team
        public IActionResult AddCharacter(int teamId)
        {
            var team = _context.Teams.FirstOrDefault(t => t.Id == teamId);

            if (team == null)
            {
                return NotFound();
            }

            ViewBag.TeamName = team.Name;
            ViewBag.TeamId = teamId;

            return View();
        }

        // Saves a new character to a specific team
        [HttpPost]
        public IActionResult SaveCharacter(int TeamId, string Name, int Health, int Strength, int Speed)
        {
            var team = _context.Teams
                .Include(t => t.Characters)
                .FirstOrDefault(t => t.Id == TeamId);

            if (team == null)
            {
                return NotFound();
            }

            var character = new Character
            {
                Name = Name,
                Health = Health,
                Strength = Strength,
                Speed = Speed,
            };

            team.Characters.Add(character);
            _context.SaveChanges();

            return RedirectToAction("Details", "Teams", new { id = TeamId });
        }

        // Displays the customize page for a team's characters
        public IActionResult Customize(int teamId)
        {
            var team = _context.Teams
                .Include(t => t.Characters)
                .FirstOrDefault(t => t.Id == teamId);

            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // Updates the stats of characters in a specific team
        [HttpPost]
        public IActionResult Customize(int teamId, List<Character> updatedCharacters)
        {
            var team = _context.Teams
                .Include(t => t.Characters)
                .FirstOrDefault(t => t.Id == teamId);

            if (team == null)
            {
                TempData["ErrorMessage"] = "Team not found.";
                return RedirectToAction("Index", "Teams");
            }

            foreach (var updatedCharacter in updatedCharacters)
            {
                var existingCharacter = team.Characters.FirstOrDefault(c => c.Id == updatedCharacter.Id);

                if (existingCharacter != null && Character.ValidateStats(updatedCharacter, 100))
                {
                    existingCharacter.Strength = updatedCharacter.Strength;
                    existingCharacter.Defense = updatedCharacter.Defense;
                    existingCharacter.Speed = updatedCharacter.Speed;
                    existingCharacter.Health = updatedCharacter.Health;
                }
                else
                {
                    TempData["ErrorMessage"] = $"Invalid stats for character {updatedCharacter.Name}.";
                    return RedirectToAction("Customize", new { teamId = teamId });
                }
            }

            _context.SaveChanges();
            TempData["SuccessMessage"] = "Character stats updated successfully!";
            return RedirectToAction("Index", "Teams");
        }
    }
}
